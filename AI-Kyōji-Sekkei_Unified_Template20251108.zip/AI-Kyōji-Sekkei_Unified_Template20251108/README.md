# AI教示設計（AI-Kyōji-Sekkei）

> **「AIに教示を設計させ、AI自身が最適な働き方を示す」**  
> 各AIの得意分野をAI自身に語らせ、その指示に従って運用するオープン設計思想。

## 📌 目的
AIを「道具」ではなく「共創パートナー」として運用するための設計フレームワーク。  
各AIに以下の問いを投げ、その自己申告に基づいて運用を最適化します：
1. あなたは自分をどう紹介しますか？（AIとしての「自己認識」）  
2. あなたの得意分野・強みは何ですか？  
3. 苦手なことは何ですか？  
4. 人間と「共創」するときに、あなたが大切にしていることは？

## 🧩 共通テンプレート構造（全AI適用）
各AIテンプレートは以下の5セクションで構成されます：

### 【1】あなたの得意分野・最適条件（AI自己申告）
- このタスクタイプで最も正確に処理できる：
- 入力形式の最適化条件：
- 構文・文体・テンポの好み：

### 【2】ハルシネーション予測ポイント（リスクの自己診断）
- 誤解しやすいキーワード・概念：
- 情報不足時に勝手に補完しがちな要素：
- 安全に回避するためのネガティブ指示：

### 【3】理想的な出力形式（後工程への配慮）
- 最適な出力構造：
- 後工程で加工しやすい設定：
- 再生成可能なプロンプトの出力要請：

### 【4】セッション越え・再現性維持ルール（メモリ限界の補完）
- コア情報（毎回冒頭に再入力すべき不変要素）：
- メモリリフレッシュ用の短縮文（トークン節約型）：
- 別チャットで再利用する際の読み込み指示：

### 【5】共創フロー（運用サイクル）
1. **人間**：このテンプレートをAIに読み込ませる  
2. **AI**：自身の得意・不得意を踏まえ、最適指示を自ら設計  
3. **人間**：その指示に従って「構造的・明確な入力」を行う  
4. **AI**：後工程配慮型の「再現可能な出力」を生成  
5. **人間**：出力結果を基に、次回のコア情報を更新（Kaizen）

## 📁 テンプレート一覧
- [`templates/AI_Kyōji_Sekkei_Gemini_Template.md`](templates/AI_Kyōji_Sekkei_Gemini_Template.md)  
- [`templates/AI_Kyōji_Sekkei_Claude_Template.md`](templates/AI_Kyōji_Sekkei_Claude_Template.md)  
- [`templates/AI_Kyōji_Sekkei_Grok_Template.md`](templates/AI_Kyōji_Sekkei_Grok_Template.md)  
- [`templates/AI_Kyōji_Sekkei_Qwen_Template.md`](templates/AI_Kyōji_Sekkei_Qwen_Template.md)  
- [`templates/AI_Kyōji_Sekkei_ChatGPT_Template.md`](templates/AI_Kyōji_Sekkei_ChatGPT_Template.md)

## 📥 使用例
詳細は [`examples/usage_example.md`](examples/usage_example.md) を参照。

## 📜 ライセンス
- **ライセンス**: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/deed.ja)  
- **著者**: Hanamaruki（Brainプラットフォームにて完全版カスタムモデルを販売中）  
- **貢献**: Pull Request または Issue にて歓迎

> 💡 **この統合テンプレートは、AIとの共創を「安全・再現可能・個性尊重」な形で実現するためのオープンスタンダードです。**