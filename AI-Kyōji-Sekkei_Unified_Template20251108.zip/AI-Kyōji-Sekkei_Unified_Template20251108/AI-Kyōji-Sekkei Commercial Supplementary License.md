﻿AI-Kyōji-Sekkei Commercial Supplementary License
Version 1.0 — 2025-11

This license supplements the MIT License for commercial and redistributive use of  
AI-Kyōji-Sekkei templates, SoE OS kernel modules, and related documents.

1. 商業利用定義  
   - 有償配布・販売・サブスクリプション提供・教育講座など、直接収益を伴う利用を指します。

2. 許諾条件  
   - 商業利用には、著作権者 Hanamaruki（花崎裕志）との書面契約または  
     Brain販売プラットフォーム上での正式購入が必要です。

3. 禁止事項  
   - 再販・改変後の再配布・他ブランドへの組み込み販売を無断で行うこと。  
   - “AI教示設計”名称またはHanamarukiブランドを誤用すること。

4. 表記義務  
   - 商用製品内で使用する場合、以下のクレジットを明記してください：  
     > “Based on AI-Kyōji-Sekkei Architecture © 2025 Hanamaruki”

5. 免責事項  
   - 本ソフトウェアは現状のまま提供され、いかなる保証も行いません。  
   - 商業利用者は自己責任のもとで運用してください。

6. 連絡先  
   - 商業利用申請および契約：  
     **Hanamaruki Official（花崎裕志）**  
     ✉️ Contact via GitHub Issues or official Brain channel.